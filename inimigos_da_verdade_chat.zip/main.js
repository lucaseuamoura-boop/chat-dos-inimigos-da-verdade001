// CONFIG FIREBASE — substitua pelos seus dados
var firebaseConfig = {
  apiKey: "COLOQUE_AQUI",
  authDomain: "COLOQUE_AQUI",
  databaseURL: "COLOQUE_AQUI",
  projectId: "COLOQUE_AQUI",
  storageBucket: "COLOQUE_AQUI",
  messagingSenderId: "COLOQUE_AQUI",
  appId: "COLOQUE_AQUI"
};

firebase.initializeApp(firebaseConfig);
var db = firebase.database().ref("chat");

const messages = document.getElementById("messages");
const input = document.getElementById("msg");

db.on("child_added", snap => {
  let d = snap.val();
  let div = document.createElement("div");
  div.textContent = d.text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
});

function send() {
  if (input.value.trim() === "") return;
  db.push({ text: input.value });
  input.value = "";
}
